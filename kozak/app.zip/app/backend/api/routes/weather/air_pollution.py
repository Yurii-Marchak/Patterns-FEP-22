
from urllib.parse import urlencode
import requests
from fastapi import APIRouter

from backend.config import WEATHER_API_KEY

pollution_router = APIRouter(include_in_schema=True)

router = APIRouter(include_in_schema=True)

POLLUTION_WEATHER_API_URL = "http://api.weatherstack.com/current"

def get_air_quality(city):
    params = {
        "access_key": WEATHER_API_KEY,
        "query": city
    }
    response = requests.get(POLLUTION_WEATHER_API_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        return {
            "location": data.get("location", {}).get("name"),
            "air_quality": data.get("current", {}).get("air_quality")
        }
    else:
        return {"error": "Failed to fetch data"}
