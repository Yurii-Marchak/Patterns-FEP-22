import unittest
import sys
import os

# Додаємо шлях до модуля, щоб імпортувати фабрику та класи контейнерів
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from src.container_factory import ContainerFactory
from src.container import BasicContainer, HeavyContainer, RefrigeratedContainer, LiquidContainer

class TestContainerFactory(unittest.TestCase):
    def test_basic_container_creation(self):
        container_data = {
            "id": 1,
            "weight": 1000,
            "type": "basic"
        }
        container = ContainerFactory.create_container(container_data)

        print(type(container))  # Діагностичний вивід для перевірки класу
        self.assertIsInstance(container, BasicContainer)
        self.assertEqual(container.container_id, 1)
        self.assertEqual(container.weight, 1000)

    def test_heavy_container_creation(self):
        container_data = {
            "id": 2,
            "weight": 3000,
            "type": "heavy"
        }
        container = ContainerFactory.create_container(container_data)

        print(type(container))  # Діагностичний вивід для перевірки класу
        self.assertIsInstance(container, HeavyContainer)
        self.assertEqual(container.container_id, 2)
        self.assertEqual(container.weight, 3000)

    def test_refrigerated_container_creation(self):
        container_data = {
            "id": 3,
            "weight": 1500,
            "type": "refrigerated"
        }
        container = ContainerFactory.create_container(container_data)

        print(type(container))  # Діагностичний вивід для перевірки класу
        self.assertIsInstance(container, RefrigeratedContainer)
        self.assertEqual(container.container_id, 3)
        self.assertEqual(container.weight, 1500)

    def test_liquid_container_creation(self):
        container_data = {
            "id": 4,
            "weight": 2500,
            "type": "liquid"
        }
        container = ContainerFactory.create_container(container_data)

        print(type(container))  # Діагностичний вивід для перевірки класу
        self.assertIsInstance(container, LiquidContainer)
        self.assertEqual(container.container_id, 4)
        self.assertEqual(container.weight, 2500)

if __name__ == "__main__":
    unittest.main()
