import unittest
import sys
import os

# Додаємо шлях до модуля, якщо ship_builder і port знаходяться в іншій директорії
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from src.ship_builder import ShipBuilder
from src.port import Port

class TestShip(unittest.TestCase):
    def setUp(self):
        # Ініціалізація порту для тестування
        self.port = Port(1, 48.858844, 2.294351)

    def test_ship_creation(self):
        # Використовуємо будівельник для створення корабля
        builder = ShipBuilder() \
            .set_id(1) \
            .set_fuel(1000) \
            .set_current_port(self.port) \
            .set_max_weight(5000) \
            .set_max_containers(10) \
            .set_fuel_consumption(10)

        ship = builder.build()

        # Перевірка, чи корабель правильно створений
        self.assertEqual(ship.ship_id, 1)
        self.assertEqual(ship.fuel, 1000)
        self.assertEqual(ship.current_port, self.port)
        self.assertEqual(ship.max_weight, 5000)
        self.assertEqual(ship.max_containers, 10)
        self.assertEqual(ship.fuel_consumption_per_km, 10)

if __name__ == "__main__":
    unittest.main()
