# ship_builder.py
from ship import Ship

class ShipBuilder:
    def __init__(self):
        self.ship_id = None
        self.fuel = 0.0
        self.current_port = None
        self.max_weight = 0
        self.max_containers = 0
        self.fuel_consumption_per_km = 0.0

    def set_id(self, ship_id):
        self.ship_id = ship_id
        return self

    def set_fuel(self, fuel):
        self.fuel = fuel
        return self

    def set_current_port(self, current_port):
        self.current_port = current_port
        return self

    def set_max_weight(self, max_weight):
        self.max_weight = max_weight
        return self

    def set_max_containers(self, max_containers):
        self.max_containers = max_containers
        return self

    def set_fuel_consumption(self, fuel_consumption_per_km):
        self.fuel_consumption_per_km = fuel_consumption_per_km
        return self

    def build(self):
        return Ship(self.ship_id, self.fuel, self.current_port, self.max_weight, self.max_containers, self.fuel_consumption_per_km)
