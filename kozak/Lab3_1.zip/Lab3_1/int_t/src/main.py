import json
from port import Port
from container_factory import ContainerFactory
from ship_builder import ShipBuilder
from container import BasicContainer, HeavyContainer, RefrigeratedContainer, LiquidContainer


def print_port_info(ports):
    output = {}
    for port_id, port in ports.items():
        port_info = {
            "lat": round(port.latitude, 2),
            "lon": round(port.longitude, 2),
            "basic_container": [],
            "heavy_container": [],
            "refrigerated_container": [],
            "liquid_container": []
        }

        # Сортуємо контейнери порту по типу
        for container in port.containers:
            if isinstance(container, BasicContainer):
                port_info["basic_container"].append(container.container_id)
            elif isinstance(container, RefrigeratedContainer):
                port_info["refrigerated_container"].append(container.container_id)
            elif isinstance(container, LiquidContainer):
                port_info["liquid_container"].append(container.container_id)
            elif isinstance(container, HeavyContainer):
                port_info["heavy_container"].append(container.container_id)

        # Сортуємо контейнери у порядку зростання ID
        port_info["basic_container"].sort()
        port_info["heavy_container"].sort()
        port_info["refrigerated_container"].sort()
        port_info["liquid_container"].sort()

        # Додаємо інформацію про кораблі
        for ship in port.current_ships:
            ship_info = {
                "fuel_left": round(ship.fuel, 2),
                "basic_container": [],
                "heavy_container": [],
                "refrigerated_container": [],
                "liquid_container": []
            }

            for container in ship.containers:
                if isinstance(container, BasicContainer):
                    ship_info["basic_container"].append(container.container_id)
                elif isinstance(container, RefrigeratedContainer):
                    ship_info["refrigerated_container"].append(container.container_id)
                elif isinstance(container, LiquidContainer):
                    ship_info["liquid_container"].append(container.container_id)
                elif isinstance(container, HeavyContainer):
                    ship_info["heavy_container"].append(container.container_id)

            # Сортуємо контейнери на кораблі
            ship_info["basic_container"].sort()
            ship_info["heavy_container"].sort()
            ship_info["refrigerated_container"].sort()
            ship_info["liquid_container"].sort()

            port_info[f"ship_{ship.ship_id}"] = ship_info

        output[f"Port {port_id}"] = port_info

    print(json.dumps(output, indent=4))


def main():
    try:
        # Читання конфігурації із JSON-файлу
        with open('input.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print("Файл 'input.json' не знайдено. Будь ласка, перевірте його наявність.")
        return
    except json.JSONDecodeError:
        print("Помилка в структурі JSON-файлу. Перевірте синтаксис.")
        return

    # Створення портів
    ports = {}
    for port_data in data["ports"]:
        port = Port(port_data["id"], port_data["latitude"], port_data["longitude"])
        ports[port_data["id"]] = port

    # Створення кораблів за допомогою будівельника
    ships = {}
    for ship_data in data["ships"]:
        ship_builder = ShipBuilder() \
            .set_id(ship_data["id"]) \
            .set_fuel(ship_data["fuel"]) \
            .set_current_port(ports[ship_data["current_port"]]) \
            .set_max_weight(ship_data["max_weight"]) \
            .set_max_containers(ship_data["max_containers"]) \
            .set_fuel_consumption(ship_data["fuel_consumption_per_km"])

        ship = ship_builder.build()
        ships[ship_data["id"]] = ship
        ports[ship_data["current_port"]].incoming_ship(ship)

    # Створення контейнерів за допомогою фабрики
    containers = {}
    for container_data in data["containers"]:
        container = ContainerFactory.create_container(container_data)
        containers[container_data["id"]] = container
        ports[1].containers.append(container)  # Для демонстрації всі контейнери в першому порту

    # Виведення даних про порти та кораблі
    print_port_info(ports)


if __name__ == "__main__":
    main()
