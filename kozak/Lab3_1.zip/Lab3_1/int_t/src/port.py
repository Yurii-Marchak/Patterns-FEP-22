# port.py
from typing import TYPE_CHECKING
from i_port import IPort

if TYPE_CHECKING:
    from ship import Ship


class Port(IPort):
    def __init__(self, port_id, latitude, longitude):
        self.port_id = port_id
        self.latitude = latitude
        self.longitude = longitude
        self.containers = []
        self.history = []
        self.current_ships = []

    def incoming_ship(self, ship: 'Ship'):
        if ship not in self.current_ships:
            self.current_ships.append(ship)
        if ship not in self.history:
            self.history.append(ship)

    def outgoing_ship(self, ship: 'Ship'):
        if ship in self.current_ships:
            self.current_ships.remove(ship)

    def get_distance(self, other_port):
        from math import radians, sin, cos, sqrt, atan2
        R = 6371  # Радіус Землі в кілометрах
        lat1, lon1 = radians(self.latitude), radians(self.longitude)
        lat2, lon2 = radians(other_port.latitude), radians(other_port.longitude)
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
        c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return R * c
