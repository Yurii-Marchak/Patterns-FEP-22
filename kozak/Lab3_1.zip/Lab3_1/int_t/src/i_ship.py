from typing import TYPE_CHECKING
from abc import ABC, abstractmethod
if TYPE_CHECKING:
    from container import Container
    from port import Port

class IShip(ABC):
    @abstractmethod
    def sail_to(self, port: 'Port') -> bool:
        pass

    @abstractmethod
    def refuel(self, fuel_amount: float):
        pass

    @abstractmethod
    def load_container(self, container: 'Container') -> bool:
        pass

    @abstractmethod
    def unload_container(self, container: 'Container') -> bool:
        pass
