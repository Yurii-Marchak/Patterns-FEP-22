from typing import TYPE_CHECKING
from i_ship import IShip

if TYPE_CHECKING:

    from container import Container
    from port import Port

class Ship(IShip):
    def __init__(self, ship_id, fuel, current_port, max_weight, max_containers, fuel_consumption_per_km):
        self.ship_id = ship_id
        self.fuel = fuel
        self.current_port = current_port
        self.max_weight = max_weight
        self.max_containers = max_containers
        self.fuel_consumption_per_km = fuel_consumption_per_km
        self.containers = []

    def sail_to(self, destination_port: 'Port') -> bool:
        distance = self.current_port.get_distance(destination_port)
        required_fuel = distance * self.fuel_consumption_per_km
        if self.fuel >= required_fuel:
            self.fuel -= required_fuel
            self.current_port.outgoing_ship(self)
            destination_port.incoming_ship(self)
            self.current_port = destination_port
            return True
        return False

    def refuel(self, fuel_amount: float):
        self.fuel += fuel_amount

    def load_container(self, container: 'Container') -> bool:
        if len(self.containers) < self.max_containers:
            self.containers.append(container)
            return True
        return False

    def unload_container(self, container: 'Container') -> bool:
        if container in self.containers:
            self.containers.remove(container)
            return True
        return False
