from typing import TYPE_CHECKING
from abc import ABC, abstractmethod

if TYPE_CHECKING:
    from ship import Ship

class IPort(ABC):
    @abstractmethod
    def incoming_ship(self, ship: 'Ship'):
        pass

    @abstractmethod
    def outgoing_ship(self, ship: 'Ship'):
        pass
