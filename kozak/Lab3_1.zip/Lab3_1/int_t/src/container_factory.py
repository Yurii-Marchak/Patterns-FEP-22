# container_factory.py
from container import BasicContainer, HeavyContainer, RefrigeratedContainer, LiquidContainer

class ContainerFactory:
    @staticmethod
    def create_container(container_data):
        container_type = container_data["type"]
        if container_type == "basic":
            return BasicContainer(container_data["id"], container_data["weight"])
        elif container_type == "heavy":
            return HeavyContainer(container_data["id"], container_data["weight"])
        elif container_type == "refrigerated":
            return RefrigeratedContainer(container_data["id"], container_data["weight"])
        elif container_type == "liquid":
            return LiquidContainer(container_data["id"], container_data["weight"])
        else:
            raise ValueError(f"Unknown container type: {container_type}")
