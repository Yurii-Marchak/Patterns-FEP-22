import httpx

from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse
from backend.config import  config
from backend.models.forecast import ForecastResponse
from backend.api.routes.weather.current import ClientFactory
from fastapi.templating import Jinja2Templates
from backend.api.routes.weather.utils import handle_api_errors

forecast_router = APIRouter()
FORECAST_WEATHER_API_URL = "https://api.weatherapi.com/v1/forecast.json"
templates = Jinja2Templates(directory="frontend")

@forecast_router.get("/forecast/data", response_model=ForecastResponse)
async def get_weather_forecast(city: str, days: int = 3):
    client = ClientFactory.create_client("weather")
    url = f"https://api.weatherapi.com/v1/forecast.json?key={config.WEATHER_API_KEY}&q={city}&days={days}"

    async with client:
        response = await client.get(url)
        response.raise_for_status()
        data = response.json()

    return ForecastResponse(
        location=data["location"],
        forecast=data["forecast"]["forecastday"]
    )