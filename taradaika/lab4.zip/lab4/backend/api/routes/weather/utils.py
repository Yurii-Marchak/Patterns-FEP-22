from urllib.parse import urlencode

from backend.config import config
from fastapi import HTTPException
from httpx import HTTPStatusError, RequestError
import functools

def handle_api_errors(func):
    """Decorator to handle errors from the weather API."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except HTTPStatusError as e:
            raise HTTPException(
                status_code=e.response.status_code,
                detail=f"API Error: {e.response.text}"
            )
        except RequestError as e:
            raise HTTPException(
                status_code=503,
                detail="Service unavailable. Please try again later."
            )
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"An unexpected error occurred: {str(e)}"
            )
    return wrapper


def build_weather_query(base_url: str, city: str, imperial=False) -> str:
    """Builds the URL for an API request to OpenWeather's weather API.

    Args:
        base_url (str): base url to request
        city (str): Name of a city as collected by argparse
        imperial (bool): Use or not imperial units for temperature

    Returns:
        str: URL formatted for a call to OpenWeather's city name endpoint
    """
    units = "imperial" if imperial else "metric"
    request_data = {'q': city,
                    'appid': config,
                    'units': units}
    url_values = urlencode(request_data)
    full_url = base_url + '?' + url_values
    return full_url
