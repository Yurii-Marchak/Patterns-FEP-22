import httpx
from fastapi import APIRouter, HTTPException
from httpx import AsyncClient
from backend.config import config
from backend.db.crud import *
from backend.api.routes.weather.utils import handle_api_errors


current_router = APIRouter(include_in_schema=True)
CURRENT_WEATHER_API_URL = "https://api.weatherapi.com/v1/current.json"


class ClientFactory:
    """Factory Method for creating API clients."""

    @staticmethod
    def create_client(client_type: str) -> AsyncClient:
        if client_type == "weather":
            return AsyncClient(base_url="https://api.weatherapi.com/v1")
        elif client_type == "other_api":
            return AsyncClient(base_url="https://other-api.com/v1")
        else:
            raise ValueError(f"Unknown client type: {client_type}")


@current_router.get("/current/")
@handle_api_errors
async def get_weather_info(city: str):
    """Returns current weather info from WeatherAPI.

    Args:
        city (str): Name of a city

    Returns:
        weather_info (dict~json): Current weather info in specified city.
    """
    client = ClientFactory.create_client("weather")
    url = f"{CURRENT_WEATHER_API_URL}?key={config.WEATHER_API_KEY}&q={city}"
    async with client:
        response = await client.get(url)
        response.raise_for_status()
        weather_info = response.json()
    return weather_info

@current_router.post("/current", response_model=WeatherSchema)
@handle_api_errors
async def create_weather_report(report: WeatherSchema):
    """Creates a new weather report."""
    weather_report = await get_by_city(city=report.city)
    if weather_report is not None:
        raise HTTPException(409, "The forecast already exists")
    weather_report = await create(report=report)

    return weather_report

@current_router.get("/current/{city}", response_model=WeatherSchema)
@handle_api_errors
async def get_weather_by_city(city: str):
    weather_report = await get_by_city(city=city)
    if weather_report is None:
        raise HTTPException(404, "The forecast for the current city is not found")
    return weather_report

@current_router.get("/current/all/", response_model=List[WeatherSchema])
@handle_api_errors
async def get_all_reports():
    weather_reports = await get_all()
    if weather_reports is None:
        raise HTTPException(404, "Database is empty")
    return weather_reports

@current_router.put("/current/", response_model=WeatherSchema)
@handle_api_errors
async def update_report(report: WeatherSchema):
    weather_report = await update(report=report)
    if weather_report is None:
        raise HTTPException(404, "There was an error updating the weather report.")
    return weather_report
