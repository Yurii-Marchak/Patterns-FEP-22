from fastapi import FastAPI
from contextlib import asynccontextmanager
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from beanie import init_beanie

from backend.api.routes import router as main_router
from backend.db.database import client
from backend.models.current_weather import __beanie_models__

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_beanie(database=client.db_name, document_models=__beanie_models__)
    yield
    client.close()


app = FastAPI(title="Weather Report", lifespan=lifespan)

app.include_router(main_router)
app.mount("/static", StaticFiles(directory="frontend"), name="static")
app.mount("/frontend", StaticFiles(directory="frontend"), name="frontend")


@app.get("/", response_class=HTMLResponse)
async def read_root():
    with open("frontend/index.html") as f:
        return f.read()

@app.get("/forecast/data/", response_class=HTMLResponse)
async def read_forecast():
    with open("frontend/forecast.html") as f:
        return f.read()




