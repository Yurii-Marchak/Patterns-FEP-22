import os
from dotenv import load_dotenv


load_dotenv()

class Config:

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance.WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
            cls._instance.MONGODB_USERNAME = os.getenv("MONGO_INITDB_ROOT_USERNAME")
            cls._instance.MONGODB_PASSWORD = os.getenv("MONGO_INITDB_ROOT_PASSWORD")
            cls._instance.MONGO_DATABASE = os.getenv("MONGO_INITDB_DATABASE")
            cls._instance.MONGODB_PORT = os.getenv("MONGODB_PORT")
            cls._instance.MONGODB_HOST = os.getenv("MONGODB_HOST")
            cls._instance.MONGODB_URL = (
                f"mongodb://{cls._instance.MONGODB_USERNAME}:"
                f"{cls._instance.MONGODB_PASSWORD}@{cls._instance.MONGODB_HOST}:"
                f"{cls._instance.MONGODB_PORT}/{cls._instance.MONGO_DATABASE}"
                "?authSource=admin"
            )
        return cls._instance


config = Config()