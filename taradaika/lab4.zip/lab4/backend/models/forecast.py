from typing import List
from pydantic import BaseModel, Field
from datetime import datetime

class Condition(BaseModel):
    text: str
    icon: str
    code: int

class DayForecast(BaseModel):
    maxtemp_c: float
    mintemp_c: float
    avgtemp_c: float
    maxwind_kph: float
    totalprecip_mm: float
    condition: Condition

class ForecastDay(BaseModel):
    date: str
    day: DayForecast

class Location(BaseModel):
    name: str
    region: str
    country: str
    lat: float
    lon: float
    localtime: str

class ForecastResponse(BaseModel):
    location: Location
    forecast: List[ForecastDay]
