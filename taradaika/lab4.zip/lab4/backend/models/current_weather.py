"""Current weather report model"""

from typing import Tuple, Optional, List
from datetime import datetime
from beanie import Document, Indexed
from pydantic import BaseModel, Field


class WeatherSchema(BaseModel):

    city: str
    region: str
    country: str
    coordinates: Tuple[float, float]
    localtime: datetime

    temperature_c: float
    feels_like_c: float
    is_day: int
    condition_text: str
    icon: str
    wind_kph: float
    wind_dir:float
    pressure_mb: float
    humidity: int
    cloud: int
    vis_km: float
    uv: float
    gust_kph: float

    class Config:
        arbitrary_types_allowed = True



class WeatherReport(Document, WeatherSchema):
    def __repr__(self) -> str:
        return f"<WeatherReport {self.city}>"

    def __str__(self) -> str:
        return self.city

    def __hash__(self) -> int:
        return hash(self.city)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, WeatherReport):
            return self.city == other.city
        return False

    @property
    def created(self) -> datetime:
        """Datetime weather report was created from ID"""
        return self.id.generation_time

    @classmethod
    async def by_city(cls, city: str) -> "WeatherReport":
        """Get a weather report by city"""
        return await cls.find_one({"city": city})


__beanie_models__ = [WeatherReport]

