from typing import List, Optional
from backend.models.current_weather import WeatherSchema, WeatherReport


async def create(report: WeatherSchema) -> WeatherSchema:
    weather_report = WeatherReport(**report.model_dump())
    print(report.model_dump())
    await weather_report.insert()
    return report


async def get_by_city(city: str) -> Optional[WeatherReport]:
    weather_report = await WeatherReport.find_one(WeatherReport.city == city)
    return weather_report


async def get_all() -> List:
    reports = await WeatherReport.find_all().to_list()
    return reports


async def update(report: WeatherSchema) -> WeatherReport:
    to_update = await WeatherReport.find_one(WeatherReport.city == report.city)
    await to_update.set({
        "region": report.region,
        "country": report.country,
        "coordinates": report.coordinates,
        "localtime": report.localtime,
        "temperature_c": report.temperature_c,
        "feels_like_c": report.feels_like_c,
        "is_day": report.is_day,
        "condition_text": report.condition_text,
        "icon": report.icon,
        "wind_kph": report.wind_kph,
        "wind_dir": report.wind_dir,
        "pressure_mb": report.pressure_mb,
        "humidity": report.humidity,
        "cloud": report.cloud,
        "vis_km": report.vis_km,
        "uv": report.uv,
        "gust_kph": report.gust_kph,
    })
    return to_update


async def delete(city: str) -> bool:
    to_delete = await WeatherReport.find_one(WeatherReport.city == city)
    if to_delete:
        await to_delete.delete()
        return True
